package com.example.zavrsni_projekt_g3p;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class meni extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meni);
    }
}