package com.example.zavrsni_projekt_g3p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    EditText name;
    EditText password;
    EditText email;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = (EditText) findViewById(R.id.name);
        password = (EditText) findViewById(R.id.password);
        email = (EditText) findViewById(R.id.email);
        button = (Button) findViewById(R.id.button);



        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                String name1 = name.getText().toString();
                String password1 = password.getText().toString();
                String email1 = email.getText().toString();
                intent.putExtra("name",name1);
                intent.putExtra("password",password1);
                intent.putExtra("email",email1);
                startActivity(intent);
            }
        };
        button.setOnClickListener(listener);
    }
}