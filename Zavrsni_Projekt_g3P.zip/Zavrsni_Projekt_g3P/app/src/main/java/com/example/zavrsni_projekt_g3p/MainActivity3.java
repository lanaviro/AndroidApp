package com.example.zavrsni_projekt_g3p;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity3 extends AppCompatActivity {
    EditText lozinka1;
    EditText lozinka2;
    Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        lozinka1 = (EditText) findViewById(R.id.editTextText);
        lozinka2 = (EditText) findViewById(R.id.editTextText2);
        button = (Button) findViewById(R.id.button2);


        Intent intent = getIntent();
        String password1 = intent.getStringExtra("password");

        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(lozinka1.toString() == password1){

                }
            }
        };
        button.setOnClickListener(listener);
    }
}